<!-- Explain the purpose of the new analysis. -->
1.analyse th Total fare among  cityies 
 <!-- Using images from the summary DataFrame and multiple-line chart, describe the differences in ride-sharing data among the different city types -->
2.urban city type have high total fares
<!-- Based on the results, provide three business recommendations to the CEO for addressing any disparities among the city types -->
Rural total fare is the lowest but it is most average fare per dirver so some drivers move to the rural 